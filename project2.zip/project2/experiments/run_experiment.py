from src.evaluate import main
if __name__ == "__main__":
    main("results")
